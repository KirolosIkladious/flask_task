from flask import Flask, render_template, jsonify

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/api/status")
def status():
    return jsonify({
        "status": "success",
        "message": "Flask app is running!",
        "version": "1.0"
    })


if __name__ == "__main__":
    app.run(debug=True)